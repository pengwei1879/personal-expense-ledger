import { mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, "..", "data");
const dbPath = join(dataDir, "expenses.sqlite");

mkdirSync(dataDir, { recursive: true });

export const db = new DatabaseSync(dbPath);

db.exec(`
  CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'General',
    amount REAL NOT NULL CHECK(amount >= 0),
    spent_at TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

export function listExpenses({ month = "", category = "" } = {}) {
  const filters = [];
  const params = {};

  if (month) {
    filters.push("substr(spent_at, 1, 7) = $month");
    params.$month = month;
  }

  if (category) {
    filters.push("category = $category");
    params.$category = category;
  }

  const where = filters.length > 0 ? `WHERE ${filters.join(" AND ")}` : "";

  return db
    .prepare(
      `SELECT id, title, category, amount, spent_at, note, created_at
       FROM expenses
       ${where}
       ORDER BY spent_at DESC, id DESC`,
    )
    .all(params);
}

export function createExpense(expense) {
  const statement = db.prepare(`
    INSERT INTO expenses (title, category, amount, spent_at, note)
    VALUES ($title, $category, $amount, $spent_at, $note)
  `);

  const result = statement.run({
    $title: expense.title,
    $category: expense.category || "General",
    $amount: Number(expense.amount),
    $spent_at: expense.spent_at,
    $note: expense.note || "",
  });

  return db
    .prepare("SELECT * FROM expenses WHERE id = $id")
    .get({ $id: result.lastInsertRowid });
}

export function deleteExpense(id) {
  return db
    .prepare("DELETE FROM expenses WHERE id = $id")
    .run({ $id: Number(id) });
}

export function getSummary(month = "") {
  const rows = listExpenses({ month });
  const total = rows.reduce((sum, row) => sum + Number(row.amount), 0);
  const byCategory = rows.reduce((groups, row) => {
    groups[row.category] = (groups[row.category] ?? 0) + Number(row.amount);
    return groups;
  }, {});

  return { total, count: rows.length, byCategory };
}
