const form = document.querySelector("#expense-form");
const list = document.querySelector("#expense-list");
const monthFilter = document.querySelector("#month-filter");
const categoryFilter = document.querySelector("#category-filter");
const total = document.querySelector("#total");
const count = document.querySelector("#count");
const exportLink = document.querySelector("#export-link");

const today = new Date();
const currentMonth = today.toISOString().slice(0, 7);

monthFilter.value = currentMonth;
form.elements.spent_at.value = today.toISOString().slice(0, 10);

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const data = Object.fromEntries(new FormData(form));

  await fetch("/api/expenses", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  form.reset();
  form.elements.category.value = "General";
  form.elements.spent_at.value = today.toISOString().slice(0, 10);
  await refresh();
});

monthFilter.addEventListener("input", refresh);
categoryFilter.addEventListener("input", refresh);

await refresh();

async function refresh() {
  const params = new URLSearchParams();

  if (monthFilter.value) params.set("month", monthFilter.value);
  if (categoryFilter.value.trim()) params.set("category", categoryFilter.value.trim());

  const [expenses, summary] = await Promise.all([
    fetch(`/api/expenses?${params}`).then((response) => response.json()),
    fetch(`/api/summary?month=${encodeURIComponent(monthFilter.value)}`).then(
      (response) => response.json(),
    ),
  ]);

  exportLink.href = `/api/export.csv?${params}`;
  total.textContent = currency(summary.total);
  count.textContent = String(summary.count);
  renderExpenses(expenses);
}

function renderExpenses(expenses) {
  if (expenses.length === 0) {
    list.innerHTML = `<p class="empty-state">No expenses yet.</p>`;
    return;
  }

  list.innerHTML = expenses
    .map(
      (expense) => `
        <article class="expense-row">
          <div>
            <strong>${escapeHtml(expense.title)}</strong>
            <span>${escapeHtml(expense.category)} · ${escapeHtml(expense.spent_at)}</span>
            ${expense.note ? `<p>${escapeHtml(expense.note)}</p>` : ""}
          </div>
          <div class="amount-cell">
            <strong>${currency(expense.amount)}</strong>
            <button data-delete="${expense.id}" type="button">Delete</button>
          </div>
        </article>
      `,
    )
    .join("");

  list.querySelectorAll("[data-delete]").forEach((button) => {
    button.addEventListener("click", async () => {
      await fetch(`/api/expenses/${button.dataset.delete}`, { method: "DELETE" });
      await refresh();
    });
  });
}

function currency(value) {
  return new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: "USD",
  }).format(Number(value));
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
