import express from "express";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  createExpense,
  deleteExpense,
  getSummary,
  listExpenses,
} from "./db.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT ?? 8001);

app.use(express.json());
app.use(express.static(join(__dirname, "public")));

app.get("/api/expenses", (request, response) => {
  response.json(
    listExpenses({
      month: String(request.query.month ?? ""),
      category: String(request.query.category ?? ""),
    }),
  );
});

app.post("/api/expenses", (request, response) => {
  const { title, category, amount, spent_at, note } = request.body;

  if (!title || !spent_at || Number.isNaN(Number(amount))) {
    response.status(400).json({
      error: "title, amount, and spent_at are required.",
    });
    return;
  }

  response.status(201).json(
    createExpense({
      title: String(title),
      category: String(category || "General"),
      amount: Number(amount),
      spent_at: String(spent_at),
      note: String(note || ""),
    }),
  );
});

app.delete("/api/expenses/:id", (request, response) => {
  deleteExpense(request.params.id);
  response.status(204).end();
});

app.get("/api/summary", (request, response) => {
  response.json(getSummary(String(request.query.month ?? "")));
});

app.get("/api/export.csv", (request, response) => {
  const rows = listExpenses({
    month: String(request.query.month ?? ""),
    category: String(request.query.category ?? ""),
  });
  const header = ["id", "title", "category", "amount", "spent_at", "note"];
  const body = rows.map((row) =>
    header.map((field) => csvCell(row[field])).join(","),
  );

  response.setHeader("Content-Type", "text/csv; charset=utf-8");
  response.setHeader("Content-Disposition", "attachment; filename=expenses.csv");
  response.send([header.join(","), ...body].join("\n"));
});

app.listen(port, () => {
  console.log(`Personal Expense Ledger is running at http://127.0.0.1:${port}`);
});

function csvCell(value) {
  const text = String(value ?? "");
  return `"${text.replaceAll('"', '""')}"`;
}
